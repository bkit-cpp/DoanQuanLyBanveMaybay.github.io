package maybay;

public interface DocghiFile {
public void docfile();
public void ghifile();
}
